from django.db import models


class users(models.Model):
    # id
    first_name = models.TextField(max_length=255)
    last_name = models.TextField(max_length=255)
    email_address = models.CharField(max_length=255)
    age = models.IntegerField(45)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
# Create your models here.
