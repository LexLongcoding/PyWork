from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Trip, User
from datetime import datetime
# Create your views here.

"""Hello!   I tried pretty hard, i haven't really slept and im running out of energy.  I'm going to throw in the towel here i guess.
i wasn't able to get the trips to load on the travels page at first for a long time.  
i realized i didn't set the context for the travel page after a lot of looking on the platform, thats what cost me the most time.   
i wasn't able to get the name of the user to load on the travels page.  Once i realized that the trips listed should only be the ones the logged in user had entered i was stumped.  
I tried to make a many to many table for the other users trips. 
any feedback you can give is appreciated.  i'll schedule a code review if we can do that. """

def index(request):
    return render(request, 'index.html')

def register(request):
    if request.method == "GET":
        return redirect('/')
    errors = User.objects.validate(request.POST)
    if errors:
        for e in errors.values():
            messages.error(request, e)
        return redirect('/')
    else:
        new_user = User.objects.register(request.POST)
        request.session['user_id'] = new_user.id
        messages.success(request, "You have successfully registered!")
        return redirect('/travels')

def login(request):
    if request.method == "GET":
        return redirect('/')
    if not User.objects.authenticate(request.POST['email'], request.POST['password']):
        messages.error(request, 'Invalid Email/Password')
        return redirect('/')
    user = User.objects.get(email=request.POST['email'])
    request.session['user_id'] = user.id
    messages.success(request, "Welcome")
    return redirect('/travels')

def logout(request):
    request.session.clear()
    return redirect('/')

def success(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user
    }
    return render(request, '/travels', context)

def new(request):
    return render(request, 'addtrip.html')

def trip(request, trip_id):
    
    one_trip = Trip.objects.get(id=trip_id)
    context = {
        'trip': one_trip
    }
    return render(request, 'view.html', context)



def create(request):

    errors = Trip.objects.validate(request.POST)
    if errors:
        for (key, value) in errors.items():
            messages.error(request, value)
    else:
        trip = Trip.objects.create(
            destination = request.POST['destination'],
            description = request.POST['description'],
            start_date = request.POST['start_date'],
            end_date = request.POST['end_date']
        )
        trip.save()
    return render(request, 'travels.html')

def delete(request, trip_id):

    to_delete = Trip.objects.get(id=trip_id)
    to_delete.delete()
    return redirect('/travels')


def travels(request):
    context = {
        "trips": Trip.objects.all()
        #"user" : User.objects.all()
    }

    return render(request, 'travels.html', context)

def view(request, trip_id):
    context = {
        "trip":Trip.objects.get(id=trip_id)
    }
    return render(request, 'view.html', context)