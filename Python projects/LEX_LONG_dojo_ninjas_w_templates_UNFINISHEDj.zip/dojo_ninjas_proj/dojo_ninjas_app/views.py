from django.shortcuts import render, redirect

def index(request):
    return render(request, 'index.html')

def process(request):
    if request.method == 'POST':
        context = {
            #'name': request.POST['name'],
            'city': request.POST['city'],
            'state': request.POST['state']
        }
        return render(request, 'result.html', context)
    return render(request, 'result.html')

def add_ninja(request):
    if request.method == 'POST':
        context = {
            'first_name': request.POST['first_name'],
            'last_name': request.POST['last_name'],
            'dojo': request.POST['dojo']
        }
        return render(request, 'ninja.html', context)
    return render(request, 'ninja.html')





# Create your views here.
