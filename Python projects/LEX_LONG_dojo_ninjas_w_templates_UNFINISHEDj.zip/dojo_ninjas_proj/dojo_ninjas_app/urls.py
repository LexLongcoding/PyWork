from django.urls import path
from . import views	

urlpatterns = [
    path('', views.index),
    path('process',views.process),
    path('add_ninja',views.add_ninja)

]