from django.urls import path
from . import views

urlpatterns = [
    path('',views.index),
    path('register', views.register),
    path('login', views.login),
    path('logout', views.logout),
    path('dashboard', views.dashboard),
    path('addwish', views.new),
    path('create', views.create),
    path('wish/<int:wish_id>/edit', views.edit),
    path('wish/<int:wish_id>/delete', views.delete),
    path('wish/<int:id>/grant', views.grant_wish),
    path('wish/<int:id>/delete', views.delete),
    #path('view/<int:id>', views.view)


]